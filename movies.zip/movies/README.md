**My Favourite Movies!**

A webpage showing a list of some of my favourite movies, and their trailers.

**Requirements**

Requires Python 2.7.14 to run.

**How to run the program**

To run the program you will need to have Python 2.7.14 installed and double click the entertainment_center.py, or open entertainment_center.py in IDLE and click 'Run'.


Authored by: Adam Gallant, 2018-01-05
